package com.example.rentcampadmin.Util;

public class ServerApi {

    public static final String URL_LOGIN_ADMIN = "http://192.168.1.7/RentCamp/android/admin/login.php";
    public static final String URL_REGSITER_ADMIN = "http://192.168.1.7/RentCamp/android/admin/register.php";
    public static final String URL_READ_ADMIN = "http://192.168.1.7/RentCamp/android/admin/detail_user.php";
    public static final String URL_EDIT_ADMIN = "http://192.168.1.7/RentCamp/android/admin/edit_user.php";
    public static final String URL_EDIT_PASS_ADMIN = "http://192.168.1.7/RentCamp/android/admin/edit_pass_user.php";
    public static final String URL_EDIT_UPLOAD_ADMIN = "http://192.168.1.7/RentCamp/android/admin/uploadprofile.php";

}
